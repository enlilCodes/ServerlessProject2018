//This code parses the site icanhazdadjoke and publishes the content to the sns topic once a day. Created by John Uhaneh.
'use strict';
var AWS = require('aws-sdk');
var sns = new AWS.SNS();
var request = require("request");
var cheerio = require("cheerio");
var snsrgion = process.env.AWS_REGION;
var url= 'https://icanhazdadjoke.com/';

exports.handler = function index(event, context, callback) {
var pageToVisit = url;
console.log("Visiting page " + pageToVisit);
request(pageToVisit, function(error, response, body) {
   if(error) {
     console.log("Error: " + error);
   }
   console.log("Status code: " + response.statusCode);
   if(response.statusCode === 200) {
     var $ = cheerio.load(body);
     console.log("Page body:  " + $('body').text());
   }
var sts = new AWS.STS();
sts.getCallerIdentity({}, function(err, data) {
   if (err) {
      console.log("Error", err);
   } else {
      console.log(JSON.stringify(data.Account));
      var accountId = data.Account;
   }
   sns.publish({
        Message:$('body').text() ,
       TopicArn: 'arn:aws:sns:'+snsrgion+':'+accountId+':SubscribeNow-topic',
    }, function(err, data) {
        if (err) {
            //console.log(err.stack);
            console.log("Topic issues", 'arn:aws:sns:'+snsrgion+':'+accountId+':SubscribeNow-topic');
            return;
        }
        console.log('push sent');
        console.log(data);
        context.done(null, 'Published!');  
    });
});
});
};